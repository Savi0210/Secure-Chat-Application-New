<?php
  require_once('../server/DB.php');
  $db = DB::getInstance();
?>